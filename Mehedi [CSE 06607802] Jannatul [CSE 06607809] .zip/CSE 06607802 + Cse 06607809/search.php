<?php
$conn = mysqli_connect('localhost','root','','search');
$get=$_POST['box'];
if($get)
{
    $show="SELECT * FROM old_book where Book_Name='$get'";
    $result=mysqli_query($conn,$show);
    if(mysqli_num_rows($result)==1)
    {
         while($rows=mysqli_fetch_array( $result))
    {
        echo 'Book Name:'. $rows['Book_Name'];
    }
    }
    else
    {
      echo'Book was Not found in database';  
    }
    
}
else
{
    echo'Type something to search';
}

?>