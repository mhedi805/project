<?php
    $conn = mysqli_connect('localhost','root','','register');
    $Email=$_POST['Email'];
    $password=$_POST['Password'];
if(!empty($Email) && !empty($password))
{
   $show="SELECT * FROM info where Email='".$Email."'AND Password='".$password."'limit 1";
    $result=mysqli_query($conn,$show);
    if(mysqli_num_rows($result)==1)
    {
        echo'You have logged in sucessfully';
    }
    else
    {
        echo'You have Entered wrong password or email';
    }
}
else
{
    echo'Please enter value';
}

?>