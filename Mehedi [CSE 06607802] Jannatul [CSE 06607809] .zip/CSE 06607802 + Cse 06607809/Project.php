<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Project</title>
    <link rel="stylesheet" href="Project%20ssd.css">
    <link rel="stylesheet" href="css/all.min.css">
</head>
<body>
    <div class="header">
        <nav>
            <a href="#"><img src="logo.gif" ></a>
            <a href="" class="sub">Stamford University Bangladesh</a>
            <ul>
            <li><a href="#">Home</a></li>
            <li><a href="register%20formn.php">Register</a></li>
            <li><a href="book.html">Books</a></li>
            <li><a href="request.html">Request a Book</a></li>
            <li><a href="feedback.html">Feedback</a></li>
        </ul>
            
        </nav>
    </div>
   
    <div class="myimage">
        <h4>Libray Managment</h4>
        <h1>Welcome To Our Site</h1>
    </div>
    <div class="search_box">
      <form action="search.php" method="post">
       <input type="text" name="box" placeholder="Search for a book">
        <div class="search_btn"><button type="submit" name="search"><i class="fas fa-search"></i></button></div>
        </form>
    </div>
    <div class="what">
    <h4 class="lll">Our Services</h4>
    <hr>
    <div class="cap"><i class="fas fa-user-graduate fa-10x"></i>
    <h4>Lorem ipsum dolor sit amet, consectetur adipisicing elit. <br> Ratione harum pariatur placeatsimilique.</h4>
    </div>
    <div class="versity"><i class="fas fa-university fa-10x"></i>
    <h4>Lorem ipsum dolor sit amet, consectetur adipisicing elit. <br> Ratione harum pariatur placeatsimilique.</h4>
    </div>
    <div class="book"><i class="fas fa-book-reader fa-10x"></i>
    <h4>Lorem ipsum dolor sit amet, consectetur adipisicing elit. <br> Ratione harum pariatur placeatsimilique.</h4>
    </div>
    </div>
    <div class="about">
       <div class="half">
           <h4 class="pop">About Us</h4>
           <p class="hi">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Aut adipisci, asperiores iusto dicta accusantium nemo. Deserunt sequi modi culpa vel odit illum impedit quam, dignissimos cum. Architecto consequatur eos laudantium, expedita corporis dicta assumenda cupiditate unde sed ea, quaerat eaque sequi recusandae possimus eveniet reiciendis iure repellat accusantium doloremque! Ad est in excepturi ratione doloremque quis quaerat atque eum facere, fuga vero tempore. Iure amet ex molestias aperiam dolore vitae sit veritatis nesciunt, minima, distinctio iusto ipsum, nihil ullam velit. Voluptas velit, amet officia unde recusandae magni autem libero perferendis dolorum. Odio numquam itaque cupiditate earum nobis repellendus officiis, dolorem sit quidem quo minima incidunt, sapiente porro corporis dolore exercitationem. Facere harum iusto odio ea veritatis quos aut ipsa sit aliquid. Hic, commodi. Repellendus perspiciatis dolores minus quisquam. Unde est eveniet dicta ad. A voluptatum explicabo odio laudantium dolore fugiat, doloremque temporibus laborum magni rem nulla sequi ex accusamus, sed aut! Vero.</p>
       </div>
       <div class="right"><a href="#">Explore</a></div>
        
    </div>
    
    <div class="contact"> <h2>Contact with Us.... </h2></div>
    
    
    <div class="social_icons">
      
        <a href=""><i class="fab fa-facebook-f "></i></a>
        
        <a href=""><i class="fab fa-youtube "></i></a>
        <a href=""><i class="fab fa-twitter "></i></a>
        <a href=""><i class="fab fa-linkedin-in "></i></a>
    </div>
    <div class="social_icons_b">
      
        <a href=""><i class="fab fa-facebook-f "></i></a>
        
        <a href=""><i class="fab fa-youtube "></i></a>
        <a href=""><i class="fab fa-twitter "></i></a>
        <a href=""><i class="fab fa-linkedin-in "></i></a>
    </div>
    
    
</body>
</html>
 
