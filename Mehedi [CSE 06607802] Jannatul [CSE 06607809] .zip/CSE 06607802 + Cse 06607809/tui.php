<?php

$conn = mysqli_connect('localhost','root','','request');
$First=$_POST['First'];
$Last=$_POST['Last'];
$Email=$_POST['Email'];
$password=$_POST['Password'];
if(!empty($First) && !empty($Last) && !empty($Email) && !empty($password))
{
   $show="insert into r1(Your_Name,Book_n,Author,mail)values('$First','$Last','$Email','$password')";
    mysqli_query($conn,$show);
    echo'Succesfully Requested';
}
else
{
    echo'Please enter value';
}
?>