

<?php
    $conn =mysqli_connect('localhost','root','','register');
    
   $show="SELECT * FROM info";
    $result=mysqli_query($conn,$show);
if($result){
    $output=mysqli_num_rows($result);
    
}
else{
    echo "fail";
}
    
    
    ?>
    
    
    <?php
    $conn =mysqli_connect('localhost','root','','register');
    
   $show="SELECT * FROM books";
    $result=mysqli_query($conn,$show);
if($result){
    $output1=mysqli_num_rows($result);
    
}
else{
    echo "fail";
}
    
    
    ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Document</title>
    <link rel="stylesheet" href="admin.css">
    <link rel="stylesheet" href="css/all.min.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    
</head>
<body>



 
          
               <div>
            
                    <ul class="nav nav-tabs navbar-dark bg-dark" >
            <li class="dropdown">
            <a class="dropdown-toggle" data-toggle="dropdown" href="#">Catagories
            <span class="caret"></span>
            </a>
            <ul class="dropdown-menu ">
                <li><a href="Catagories.html">Add Catagory</a></li>
                <li class="divider"></li>
                <li><a href="#">Manage Catagory</a></li>
            </ul>
            </li>
            <li class="dropdown"><a class="dropdown-toggle" data-toggle="dropdown" href="#">Books <span class="caret"></span></a>
            <ul class="dropdown-menu ">
                <li><a href="Books.html">Add Books</a></li>
                <li class="divider"></li>
                <li><a href="#">Manage Books</a></li>
            </ul>
            
            </li>
            <li class="dropdown"><a class="dropdown-toggle" data-toggle="dropdown" href="#">Issue Books <span class="caret"></span></a>
            <ul class="dropdown-menu">
                <li><a href="issue%20books.html">Issue New Books</a></li>
                <li class="divider"></li>
                <li><a href="issue%20books.html">Manage Issued Books</a></li>
            </ul>
            
            </li>
            <li class="dropdown"><a class="dropdown-toggle" data-toggle="dropdown" href="#">Late fees <span class="caret"></span></a>
            <ul class="dropdown-menu ">
                <li><a href="Add_late.html">Add Late Fees</a></li>
                <li class="divider"></li>
                <li><a href="#">Delete Late Fees</a></li>
            </ul>
            
            </li>
            <li class="dropdown">
            <a class="dropdown-toggle" data-toggle="dropdown" href="#">Manage Students
            <span class="caret"></span>
            </a>
            <ul class="dropdown-menu ">
                <li><a href="add_student.html">Add Students</a></li>
                <li class="divider"></li>
                <li><a href="#">Remove students</a></li>
            </ul>
            </li>
            
        </ul>
            
           <div class="lo">
            <form class="form-inline">
               
               <input class="form-control mr-sm-2" type="search" aria-label="search">
               <button class="btn btn-outline-success my-2 my-sm-0" type="submit">Search</button>
           </form>
        </div>
            
            </div>
             <h1 class="ui">Admin Dashboard :</h1>
             <hr class="ol">
           
            <div class="looo">
                <div class="container">
      <div class="card" class="op">
        <i class="fas fa-book fa-2x m1"></i>
        <div class="card_inner">
            <p>Books issued :</p>
            <span class=""><?php echo $output1; ?></span>
        </div>
    </div>
     <div class="card">
        <i class="fas fa-id-card fa-2x m2"></i>
        <div class="card_inner">
            <p>Times of Books issued :</p>
            <span class="">0 </span>
        </div>
    </div>
     <div class="card">
        <i class="fas fa-recycle fa-2x m3"></i>
        <div class="card_inner">
            <p>Times of Books returned :</p>
            <span class="">0</span>
        </div>
        
    </div>
       <div class="card">
        <i class="fas fa-users fa-2x m4"></i>
        <div class="card_inner">
            <p>Registered Users :</p>
            <span class=""><?php echo $output; ?></span>
        </div>
       </div>
        <div class="card">
        <i class="fas fa-user fa-2x m5"></i>
        <div class="card_inner">
            <p>Authors Listed :</p>
            <span class="">56</span>
        </div>
           </div>
        <div class="card">
        <i class="fas fa-list fa-2x m6"></i>
        <div class="card_inner">
            <p>Listed Ctagories :</p>
            <span class="">1001</span>
        </div>
   </div>
   <div class="ok">
       <img src="backgorounf.jpeg" alt="">
   </div>
    </div>
            </div>

   
</body>
</html>