<?php
$conn = mysqli_connect('localhost','root','','register');
$First2=$_POST['lol'];

if(!empty($First2))
{
   $show1="INSERT INTO `books`(`Student_Name`) VALUES ('$First2')";
    mysqli_query($conn,$show1);
    echo'Suceesfully issue';
    
}
else
{
    echo'Please enter value';
}

?>