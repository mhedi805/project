<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Document</title>
    <link rel="stylesheet" href="css/all.min.css">
    <link rel="stylesheet" href="cSs%20for%20all%20File.css">
</head>
<body>
  
    <form action="" method="post">
        <div class="ok">
            <h1 class="op">Log In</h1>
             
              <input type="mail" placeholder="Email" class="l" name="Email"><br><br>
              <input type="Password" class="l" placeholder="password" name="Password"><br><br>
              <input type="submit" class="my">
        </div>
    </form>
    <?php
    $conn =mysqli_connect('localhost','root','','register');
    $name=$_POST['Email'];
    $password=$_POST['Password'];
if(!empty($name) && !empty($password))
{
   $show="SELECT * FROM info where Email='".$name."'AND Password='".$password."'limit 1";
    $result=mysqli_query($conn,$show);
    if(mysqli_num_rows($result)==1)
    {
        header('location:Student_page.html');
    }
    else
    {
        echo'You have Entered wrong password or email';
    }
}
else
{
    echo'Please enter value';
}

?>
   
</body>
</html>