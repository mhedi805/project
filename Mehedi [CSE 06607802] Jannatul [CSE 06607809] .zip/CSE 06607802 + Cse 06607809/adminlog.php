<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Document</title>
    <link rel="stylesheet" href="css/all.min.css">
    <link rel="stylesheet" href="cSs%20for%20all%20File.css">
</head>
<body>
    <form action="" method="post">
        <div class="ok">
            <h1 class="op"> Admin Log In</h1>
             
              <input type="text" placeholder="Email" class="l" name="ok"><br><br>
              <input type="Password" class="l" placeholder="password" name="Password"><br><br>
              <input type="submit" class="my">
        </div>
    </form>
    <?php
    $conn =mysqli_connect('localhost','root','','admin');
    $name=$_POST['ok'];
    $password=$_POST['Password'];
if(!empty($name) && !empty($password))
{
   $show="SELECT * FROM admindetails where name='".$name."'AND Password='".$password."'limit 1";
    $result=mysqli_query($conn,$show);
    if(mysqli_num_rows($result)==1)
    {
        header('location:admin.php');
    }
    else
    {
        echo'You have Entered wrong password or email';
    }
}
else
{
    echo'Please enter value';
}

?>
    
</body>
</html>