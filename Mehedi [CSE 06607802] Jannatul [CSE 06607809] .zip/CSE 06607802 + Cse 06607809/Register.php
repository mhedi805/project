<?php
$conn = mysqli_connect('localhost','root','','register');
$First=$_POST['First'];
$Last=$_POST['Last'];
$Email=$_POST['Email'];
$password=$_POST['Password'];
$Department=$_POST['Department'];
$file=$_POST['file'];
if(!empty($First) && !empty($Last) && !empty($Email) && !empty($password) && !empty($Department) && !empty($file))
{
   $show="insert into info(First_Name,Last_Name,Email,Password,Department,Img)values('$First','$Last','$Email','$password','$Department','$file')";
    mysqli_query($conn,$show);
}
else
{
    echo'Please enter value';
}
$conn->close();
?>