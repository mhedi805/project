<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Document</title>
    <link rel="stylesheet" href="css%20for%20log.css">
</head>
<body>
   <?php
if(isset($_POST["login"]))
{
    $type=$_POST["login"];
    
    if($type=="student")
    {
        header('location:newform.php');
    }
    if($type=="teacher")
    {
        header('location:newform1.php');
    }
    if($type=="admin")
    {
        header('location:adminlog.php');
    }
    
}

?>
    <div class="full_body">
        <div class="form">
            <form action="" method="post">
              <h1>Log in as :</h1>
                <input type="radio" id="Student" name="login" value="student">
                <label for="student">Student Log in</label><br><br>
                <input type="radio" id="teacher" name="login" value="teacher">
                <label for="teacher">Teacher Log in</label><br><br>
               <input type="radio" id="admin" name="login" value="admin">
               <label for="admin">Admin Log in</label><br><br>
               <input type="submit" value="submit" class="oppp">
            </form>
        </div>
    </div>
</body>
</html>