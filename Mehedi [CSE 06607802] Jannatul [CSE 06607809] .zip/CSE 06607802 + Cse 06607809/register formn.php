<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>register</title>
    <link rel="stylesheet" href="css%20for%20register.css">
    <link rel="stylesheet" href="file:///C:/xampp/htdocs/My%20php/css/all.min.css">
</head>
<body>
   
    <div class="full_body">
        <div class="form">
           <h1>Register Here</h1>
           <form action="Register.php" method="post">
            <label for="">First Name :</label><br>
            <input type="text" placeholder="First name" name="First"><br><br>
            <label for="">Last Name :</label><br>
            <input type="text" placeholder="Last Name" name="Last"><br><br>
            <label for="">Email :</label><br>
            <input type="email" placeholder="Email" name="Email"><br><br>
            <label for="">Password</label><br>
            <input type="Password"  placeholder="Password" name="Password"><br><br>
            <label for="">Department :</label><br>
             <select name="Department" id="">
             <option value="Bangla">Bangla</option>
             <option value="English">English</option>
             <option value="CSE">CSE</option>
             <option value="EEE">EEE</option>
         </select><br><br>
           <label >Upload Your photo :</label><br><br>
         <input type="file" name="file"><br><br>
         <input type="Submit" value="submit" class="l">&nbsp;&nbsp;
          <input type="Reset" value="Reset" class="l">
            <p>Already have a account ?</p>&nbsp;&nbsp;
            <a href="loginoption.php">Log in</a>
            </form>
        </div>
        <div class="social_icons_b">
      
        <a href="Project.php"><i class="fas fa-home"></i></a>
        
        
    </div>
    </div>
</body>
</html>